### LOAD DATA

read.csv("data/blu_lu.csv") -> blu_landuse
read.csv("data/csr_bind.csv") -> csr_bind


## LOAD PAKCAGES

require(plyr)
require(vegan)
require(Hmisc)
require(dplyr)
require(reshape2)

analysis_type <- "CSR" # c("RD", "CSR")
ncuts         <- 5 # number of categories for land-use or radius
CSR_ag_thr_l  <- 0.25 # minimum human land use proportion for CSR analysis (luc >= this thr.)
CSR_ag_thr_h  <- 0.75 # maximum human land use proportion for CSR analysis (luc <= this thr.)
ES_thr        <- 0.2 # required ES at more disturbed (RD) or larger dist. (CSR) sites, use .1 to .5 

# abun makes it more likely to include abundant species when randomly assembling communities
# occ does the same for species found at many sites in many years
assembly      <- "random" #c("random", "occ", "abun") 

#DPC: I don't quite follow this but need to look it over///significance isn't key here so this isn't too important

#lowci95 <- function(x) {
#  sort(x)[floor(0.025*length(x))]
#}

#uppci95 <- function(x) {
#  sort(x)[ceiling(0.975*length(x))]
#}

# condensing land use to 2 categories
blu_landuse$allother <- blu_landuse$ag + blu_landuse$barren + blu_landuse$developed
blu_landuse$natural  <- blu_landuse$field + blu_landuse$forest + blu_landuse$wetland

#remove Cressoni
csr_bind <- csr_bind[,-which(colnames(csr_bind) == "Colletes_cressoni")]
str(csr_bind)
# occurrence (for non-random assembly) #DPC CHANGED AS IT SHOULD BE A 5 (species start at 5th column)
occ_bind <- ifelse(csr_bind[,5:ncol(csr_bind)] > 0, 1, 0)
head(csr_bind)
head(occ_bind)
# in the next line you can replace "ag" with e.g. "forest" or whatever else you want
# but that won't change the axis labels, need to do that manually
blu_landuse <- blu_landuse[,which(colnames(blu_landuse) %in% c("farm", "radius", "allother"))] 

# don't change this line
colnames(blu_landuse)[3] <- "ag"

#sum across years
csr_bind <- ddply(csr_bind, "farm", numcolwise(sum))
csr_bind <- csr_bind[,c(1,4:ncol(csr_bind))] # choose the columns we want - DPC: This keeps farm, year (but it is just the years summed e.g. 6033 and I think it can be removed), and all species

# the land use data has more farms than the blueberry farms i used in the Price paper
# i will change this eventually
blu_landuse <- blu_landuse[which(blu_landuse$farm %in% csr_bind$farm),] 

# add the land use columns to the bee baundance data. this automatically duplicates abundance data for us
# specifically it duplicates the farm-level abundance data for each radius
blu_csr <- cbind(blu_landuse, csr_bind)

# next part uses cut2, which is in Hmisc, it creates N cuts that equalize sample size in each category

# RD 
# cuts continuous land use data into five equally-sized categories
if(analysis_type == "RD"){blu_csr$lucat <- cut2(blu_csr$ag, g=ncuts)}

# CSR
# the cuts are now made across radii for a limited subset of data (change value after > to change subset)
# remove farms at different radii that do not have values at the land-use range (but farms re-appear at different radii)
if(analysis_type == "CSR"){
  blu_csr <- blu_csr[which(blu_csr$ag >= CSR_ag_thr_l & blu_csr$ag <= CSR_ag_thr_h),] #DPC: In between 20 and 80%
  blu_csr$lucat <- cut2(blu_csr$radius, g=ncuts)
}
spc<-nrow(blu_csr)
# make empty matrix to fill
#DPC QUESTION: We need to but sites in here correct?



blu_mat <- matrix(0, 36, ncuts)

# start at 6 because 1:5 are not species abundances: DPC: This was a 6:42 but DPC changed to 6:41 as col 41 are the cut values for the radii used.
# this creates the empirical table
# DPC: Each row is a species and each column is a cut. NEED TO ADD SITES HERE

for(i in 6:41){
  for(j in 1:ncuts){
    blu_mat[i-5,j] <- sum(blu_csr[which(blu_csr$lucat == levels(blu_csr$lucat)[j]),i])
  }
}


#write.csv(blu_csr, file = "/Users/dancariveau/Desktop/blu_csr2.csv")

# here's the table to look at
blu_mat


# DPC This helps get a lot of the SAD

# DPC big part is that this permutes species
# maintain overall preference for ag land use, and species abundances, but not species' prefs for ag land use
# permatfull is in vegan. both means both rows and columns are fixed, "i" means permute individuals
# you can change fixedmar to row, col, or none. it's interesting to comapare "col" to "both" because
# that reveals importance of the skewed SAD (spec. "col" removes the SAD and RD/CSR)
# fixedmar	character, stating which of the row/column sums should be preserved ("none", "rows", "columns", "both").

shf_mat <- permatfull(blu_mat, fixedmar = "both", shuffle = "i")[[3]][[1]]

# get services instead of abun -- NEED TO GET POLLEN DATA LOADED FOR THIS TO WORK
# blu_mat <- round(blu_mat*pollen)
# shf_mat <- round(shf_mat*pollen)

nreps <- 2000

# pick max richness of communities
nsp2 <- 36

# set up the matrix for adding species one by one
div_blumat <- vector("list", nsp2)
div_shfmat <- vector("list", nsp2)

# see how CV changes with richness for empirical and shuffled
#thr_blu <- matrix(0, nsp2, nreps)
#thr_shf <- matrix(0, nsp2, nreps)

for(j in 2:nsp2){
  
  # create lists
  # make list with sites
  div_blumat[[j]] <- vector("list", nreps)
  div_shfmat[[j]] <- vector("list", nreps)

# DPC Randomly choose to go in each site 
# WHAT does species richness mean MG: Closer to sampling from a regional pool
# What abundance do they have: 
# How many rows are you sampling
# Species in the regional pool - Sampling rows - pulls one row - now that I chose that row - it will disperse out to the sites as empirical data (if it is chose) - adding species and abundance - it is species and we add it - this
# is about species richness AND abundance - assumes no species interactions - Really needs to hit on the point that richness and abunandance - Null is adding abundances in the same way - It affects rate of increase 

# outer loop here for each farm
  
  for(i in 1:nreps){
    
    # running is the set of species included in each i loop
    # it increases with each j up to nsp2 (36)
    # can't do it below because it needs to be same set for blumat and shfmat
    if(assembly=="random"){running1 <- sample(1:nsp2, j)} # take 36 random integers
    if(assembly=="occ"){running1 <- sample(1:nsp2, j, prob=colSums(occ_bind)[1:ncol(occ_bind)])} #MG had this as 3:ncol(occ_bind) but DPC changed to 1. The first column is a species. DPC NEEDS TO LOOK THIS OVER
    
    div_blumat[[j]][[i]] <- blu_mat[running1,] #DPC not 100% sure what it is pulling out (e.g. 3 vs 1) but it is shuffling species (entire rows) but keeping column sums the same
    div_shfmat[[j]][[i]] <- shf_mat[running1,] 
    
    # requires a threshold to be met for all 'cut' categories. can change value after > to change threshold
    thr_blu[j,i] <- length(which(all(colSums(div_blumat[[j]][[i]]) > ES_thr*colSums(blu_mat)[1])))
    thr_shf[j,i] <- length(which(all(colSums(div_shfmat[[j]][[i]]) > ES_thr*colSums(shf_mat)[1])))
  }
}

# more through y axis title would be 
# "Proportion of communities meething chosen threshold at all (land use categories/radii)"
# blue is empirical gray is shuffled null

plot(rowMeans(thr_blu), type="l", col="blue", lwd=2, ylim=c(0,1), 
     ylab="Prop. communities meeting threshold", xlab="Species Richness")
lines(rowMeans(thr_shf), col="gray20", lwd=2)
#lines(apply(thr_shf, 1, lowci95), col="gray", lty=2, lwd=2)
#lines(apply(thr_shf, 1, uppci95), col="gray", lty=2, lwd=2)
#lines(apply(thr_blu, 1, lowci95), col="blue", lty=2, lwd=2)
#lines(apply(thr_blu, 1, uppci95), col="blue", lty=2, lwd=2)