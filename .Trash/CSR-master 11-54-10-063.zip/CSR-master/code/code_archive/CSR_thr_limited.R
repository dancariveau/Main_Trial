
RowVar <- function(x) {
  rowSums((x - rowMeans(x))^2)/(dim(x)[2] - 1)
}
dim(blu_landuse)[4]
read.csv("data/blu_lu.csv") -> blu_landuse
read.csv("data/csr_bind.csv") -> csr_bind

# in the next line you can replace "ag" with e.g. "forest" or whatever else you want
# but that won't change the axis labels, need to do that manually
blu_landuse <- blu_landuse[,which(colnames(blu_landuse) %in% c("farm", "radius", "ag"))] 

# don't change this line
colnames(blu_landuse)[3] <- "ag"

require(plyr)
require(vegan) 
require(Hmisc)
require(dplyr)
require(reshape2)

head(csr_bind)
#csr_bind <- bind
csr_bind <- ddply(csr_bind, "farm", numcolwise(sum))
csr_bind <- csr_bind[,c(1,4:ncol(csr_bind))] # choose the columns we want

# the land use data has more farms than the blueberry farms i used in the Price paper
# i will change this eventually
blu_landuse <- blu_landuse[which(blu_landuse$farm %in% csr_bind$farm),] 

# add the land use columns to the bee baundance data. this automatically duplicates abundance data for us
# specifically it duplicates the farm-level abundance data for each radius
blu_csr <- cbind(blu_landuse, csr_bind)

# C. cressonii isn't a sp. as far as i can tell so remove it
blu_csr <- blu_csr[,-which(colnames(blu_csr) == "Colletes_cressoni")]

# data prep done


# now make table of species by land use category

# cut2 is in Hmisc, it creates N cuts that equalize sample size in each category
# you can change ncuts if you want
ncuts <- 5

# RD (comment the following line for CSR)
# cuts continuous land use data into five equally-sized categories
#blu_csr$lucat <- cut2(blu_csr$ag, g=ncuts)

# CSR (comment the following two lines for RD)
# the cuts are now made across radii for a limited subset of data (change value after > to change subset)
blu_csr <- blu_csr[which(blu_csr$ag > 0.5),]
blu_csr$lucat <- cut2(blu_csr$radius, g=ncuts)

# make empty matrix to fill
blu_mat <- matrix(0, 36, ncuts)

# start at 6 because 1:5 are not species abundances #DPC: WHY WAS IS 42?
# this creates the empirical table
for(i in 6:41){
  for(j in 1:ncuts){
    blu_mat[i-5,j] <- sum(blu_csr[which(blu_csr$lucat == levels(blu_csr$lucat)[j]),i])
  }
}

# here's the table to look at
blu_mat

# maintain overall preference for ag land use, and species abundances, but not species' prefs for ag land use
# permatfull is in vegan. both means both rows and columns are fixed, "i" means permute individuals
# you can change fixedmar to row, col, or none. it's interesting to comapare "col" to "both" because
# that reveals importance of the skewed SAD (spec. "col" removes the SAD and RD/CSR)
shf_mat <- permatfull(blu_mat, fixedmar = "both", shuffle = "i")[[3]][[1]]

# get services instead of abun
blu_mat <- round(blu_mat*pollen)
shf_mat <- round(shf_mat*pollen)

nreps <- 1000

# pick max richness of communities
nsp2 <- 36

# set up the matrix for adding species one by one
div_blumat <- vector("list", nsp2)
div_shfmat <- vector("list", nsp2)

# see how CV changes with richness for empirical and shuffled
thr_blu <- matrix(0, nsp2, nreps)
thr_shf <- matrix(0, nsp2, nreps)

for(j in 2:nsp2){
  
  # create lists
  div_blumat[[j]] <- vector("list", nreps) #creates 2000 reps for each species
  div_shfmat[[j]] <- vector("list", nreps)
  
  for(i in 1:nreps){
    
    # running is the set of species included in each i loop
    # it increases with each j up to nsp2 (36)
    # can't do it below because it needs to be same set for blumat and shfmat
    running1 <- sample(1:nsp2, j)
    
    div_blumat[[j]][[i]] <- blu_mat[running1,]
    div_shfmat[[j]][[i]] <- shf_mat[running1,]
    
    # requires a threshold to be met for all 'cut' categories. can change value after > to change threshold
    thr_blu[j,i] <- length(which(all(colSums(div_blumat[[j]][[i]]) > 0.3*colSums(blu_mat)[1])))
    thr_shf[j,i] <- length(which(all(colSums(div_shfmat[[j]][[i]]) > 0.3*colSums(shf_mat)[1])))
    
  }
}

# more through y axis title would be 
# "Proportion of communities meething chosen threshold at all (land use categories/radii)"
# blue is empirical gray is shuffled null

plot(rowMeans(thr_blu), type="l", col="blue", lwd=2, ylim=c(0,1), 
     ylab="Prop. communities meeting threshold", xlab="Species Richness")
lines(rowMeans(thr_shf), col="gray", lty=2, lwd=2)